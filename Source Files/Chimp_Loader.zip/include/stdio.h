#ifndef stdio_h
#define stdio_h

#include "sys/types.h"

#endif /* #ifndef stdio_h */
