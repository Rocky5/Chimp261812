/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
#include "include/config.h"

void incrementNumberA(void *num);
void decrementNumberA(void *num);
void skipTenA(void *num);

void incrementNumberB(void *num);
void decrementNumberB(void *num);
void skipTenB(void *num);

void incrementNumberC(void *num);
void decrementNumberC(void *num);
void skipTenC(void *num);

void incrementNumberD(void *num);
void decrementNumberD(void *num);
void skipTenD(void *num);

void incrementNumberP(void *num);
void decrementNumberP(void *num);
void skipTenP(void *num);
