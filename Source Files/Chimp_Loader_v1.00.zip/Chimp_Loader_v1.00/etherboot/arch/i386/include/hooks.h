#ifndef ETHERBOOT_I386_HOOKS_H
#define ETHERBOOT_I386_HOOKS_H

#define arch_main(ptr)
#define arch_on_exit(status)
#define arch_relocate_to(addr)

#endif /* ETHERBOOT_I386_HOOKS_H */
