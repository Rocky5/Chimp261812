#ifndef stdlib_h
#define stdlib_h

#include "sys/types.h"

#endif /* #ifndef stdlib.h */
