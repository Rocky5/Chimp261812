#ifndef sys_types_h
#define sys_types_h

typedef unsigned short int u_int16_t;
typedef unsigned int u_int32_t;
typedef unsigned long long int u_int64_t;

#define FILE int

#endif /* #ifndef sys_types_h */
