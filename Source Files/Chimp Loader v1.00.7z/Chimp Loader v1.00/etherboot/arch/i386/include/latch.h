#ifndef LATCH_H
#define LATCH_H

#define	TICKS_PER_SEC		0x369E99

/* For different calibrators of the TSC move the declaration of
 * sleep_latch and the definitions of it's length here...
 */

#endif /* LATCH_H */
